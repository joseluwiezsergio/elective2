from django.urls import path
from . import views

urlpatterns = [
  path('', views.deflogin, name='login'),
  path('signup/', views.defsignup, name='signup'),
  path('adminlogin/', views.defadminlogin, name='adminlogin'),
  path('shop/', views.defshop, name='shop'),
  path('cart/', views.defcart, name='cart'),
  path('checkout/', views.defcheckout, name='checkout'),
  path('adminchangepass/', views.defadminchangepass, name='adminchangepass'),
  path('addingform/', views.defaddingform, name='addingform'),

  path('edit/<pd_id>/', views.defedit, name='edit'),
  path('delete/<pdd_id>/', views.defdel, name='del'),

  
  path('history/', views.defhistory, name='history'),
  path('inventory/', views.definventory, name='inventory'),
]

